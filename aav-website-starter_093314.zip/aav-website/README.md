# Arnold Automobile Ventures — website starter

A mobile-first Next.js App Router starter for AAV, using TypeScript, Tailwind CSS v4, Supabase (Postgres/Auth/Storage) and Resend. It includes the attached AAV logo, public page routes, form routes, starter schema/RLS, environment template and deployment guide.

> **Deployment note:** This is a structured implementation starter, not yet a fully production-complete CMS. The public pages and server form endpoints are scaffolded; the admin content-management screens (cars/services/gallery/settings/staff), upload compression, customer booking confirmation email, Turnstile verification, live database reads on all public pages, and storage policies need to be completed and tested before accepting real customers. Don't advertise tow dispatch as guaranteed until your real operating hours and process are configured.

## Routes
- `/` home
- `/services`, `/cars`, `/work`, `/about`, `/reviews`, `/book`, `/tow`, `/contact`
- `/admin` Supabase email/password sign-in starter
- `/api/bookings`, `/api/tow-requests`, `/api/reviews` form endpoints

## Requirements
- Node.js 20.9+
- Supabase project
- Resend account and verified sending domain for production mail
- Vercel account (or any Next.js-compatible host)

## Local setup
1. Download/extract this folder and open a terminal in it.
2. Install dependencies: `npm install`.
3. Copy `.env.example` to `.env.local` and fill the Supabase project URL, anon key, service-role key, Resend key and notification email list.
4. In Supabase SQL Editor, run `supabase/schema.sql`.
5. In Supabase Authentication, create an Owner user manually. Copy the user's UUID from Authentication and run the Owner bootstrap SQL at the bottom of `supabase/schema.sql`, replacing `YOUR_AUTH_USER_UUID`.
6. In Supabase Storage, create a bucket named `aav-media`. Set it to public for public vehicle/work photos and configure upload policies so only authenticated, authorized staff can upload/delete. Do not expose the service-role key to the browser.
7. Run `npm run dev` and open `http://localhost:3000`.

## Environment variables
See `.env.example`. `SUPABASE_SERVICE_ROLE_KEY` must only be used server-side. Add `AAV_NOTIFICATION_EMAILS=owner@example.com,manager@example.com` to `.env.local` for current server-side notifications. The eventual admin settings screen should persist notification recipients in `site_settings` and use an authenticated server endpoint to update them.

## Deploy to Vercel
1. Push the project to a private GitHub repository.
2. In Vercel, choose **Add New → Project**, import the repository and keep the Next.js defaults.
3. Add every required environment variable from `.env.example` in Project Settings → Environment Variables. Set `NEXT_PUBLIC_SITE_URL` to the final HTTPS domain. Add `AAV_NOTIFICATION_EMAILS` as a comma-separated list.
4. Deploy. If you change environment variables, redeploy the project.
5. In Supabase Auth URL Configuration, set the production Site URL and allowed redirect URLs to your final domain.
6. Verify Resend sender domain and DNS before relying on production email.
7. Test forms, mobile layouts, auth, database policies and email delivery in a staging environment before launch.

## Brand and content
The attached logo is saved as `public/aav-logo.png`. The temporary phone/WhatsApp number currently shown in the UI is `+234 808 146 4333`; replace it everywhere with the official number when confirmed. The exact business address, email, service prices, tow operating hours, inventory and reviews are intentionally not fabricated.

## Security and launch checklist
- Keep service-role and Resend secrets server-side only.
- Add Turnstile verification (both browser widget and server verification) or another rate-limiting service before public launch. Honeypot fields are included but are not sufficient by themselves.
- Add rate limiting and structured error monitoring to form endpoints.
- Finish staff management with server-side authorization; do not trust client-side role checks.
- Add Storage RLS policies for uploads and validate MIME types/file sizes. Compress images before upload.
- Ensure all admin mutations are logged and validate inputs server-side.
- Add public-page database queries, filters, sitemap generation and JSON-LD LocalBusiness schema before launch.
- Test backups, account recovery and the owner/staff permission matrix.

## Current form behavior
Booking, tow and review endpoints write to Supabase using a server-only service role and send email notifications through Resend. The service role bypasses RLS, so these endpoints validate input but should additionally be protected with verified Turnstile and rate limits. If email delivery fails after a database insert, the API currently returns an error; add a notification queue/outbox for resilient production delivery.
