import type { Metadata } from 'next';
import './globals.css';
import Header from '@/components/header';
import Footer from '@/components/footer';
export const metadata: Metadata = { title: { default: 'Arnold Automobile Ventures | Drive Your Tomorrow', template: '%s | Arnold Automobile Ventures' }, description: 'Vehicle sales, diagnostics, mechanical repairs and towing support in Abuja, Nigeria.', metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'), openGraph: { title: 'Arnold Automobile Ventures', description: 'Drive Your Tomorrow', type: 'website' } };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en-NG"><body><Header/><main>{children}</main><Footer/><a className="btn" style={{position:'fixed',right:16,bottom:16,zIndex:40,borderRadius:99}} href="https://wa.me/2348081464333" target="_blank" rel="noreferrer" aria-label="Chat with AAV on WhatsApp">WhatsApp Us</a></body></html>; }
