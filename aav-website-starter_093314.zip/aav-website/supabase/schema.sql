-- Arnold Automobile Ventures starter schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;
create type public.app_role as enum ('owner','staff');
create type public.booking_status as enum ('New','Confirmed','Completed','Cancelled');
create type public.tow_status as enum ('New','Dispatched','Completed','Cancelled');

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role public.app_role not null default 'staff',
  active boolean not null default true,
  permissions jsonb not null default '{"bookings":true,"tows":true,"reviews":false,"cars":false,"services":false,"work":false,"settings":false,"staff":false}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.bookings (
 id uuid primary key default gen_random_uuid(), name text not null, phone text not null, email text,
 car text, service text not null, preferred_date date, preferred_time text, message text,
 status public.booking_status not null default 'New', internal_notes text, created_at timestamptz not null default now()
);
create table if not exists public.tow_requests (
 id uuid primary key default gen_random_uuid(), name text not null, phone text not null,
 current_location text not null, destination text, car text, issue_type text not null default 'Other', notes text,
 status public.tow_status not null default 'New', internal_notes text, created_at timestamptz not null default now()
);
create table if not exists public.reviews (
 id uuid primary key default gen_random_uuid(), name text not null, rating int not null check(rating between 1 and 5),
 body text not null, approved boolean not null default false, created_at timestamptz not null default now()
);
create table if not exists public.cars (
 id uuid primary key default gen_random_uuid(), make text not null, model text not null, year int, mileage_km int,
 price_ngn bigint, status text not null default 'Available' check(status in ('Available','Sold')),
 featured boolean not null default false, description text, photos text[] not null default '{}', created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.services (
 id uuid primary key default gen_random_uuid(), name text not null, description text not null default '', price_ngn bigint,
 price_text text not null default 'Contact for quote', featured boolean not null default false, active boolean not null default true,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.work_gallery (
 id uuid primary key default gen_random_uuid(), title text not null, description text not null default '', service_type text not null default '',
 before_photos text[] not null default '{}', after_photos text[] not null default '{}', published boolean not null default false,
 created_at timestamptz not null default now()
);
create table if not exists public.site_settings (
 id int primary key default 1 check(id=1), phone text not null default '+2348081464333', whatsapp text not null default '2348081464333',
 email text not null default '', address text not null default 'Abuja, FCT, Nigeria', map_url text not null default '',
 business_hours jsonb not null default '{"monday":"09:00-18:00","tuesday":"09:00-18:00","wednesday":"09:00-18:00","thursday":"09:00-18:00","friday":"09:00-18:00","saturday":"10:00-16:00","sunday":"closed"}'::jsonb,
 tow_24_7 boolean not null default false, tow_hours jsonb not null default '{}'::jsonb, tow_unavailable boolean not null default false,
 tow_unavailable_message text not null default '', tow_pricing_text text not null default 'Contact us for a tow quote', notification_emails text[] not null default '{}',
 about_content jsonb not null default '{"story":"Add the approved AAV company story.","mission":"Drive Your Tomorrow."}'::jsonb,
 social_links jsonb not null default '{}'::jsonb, updated_at timestamptz not null default now()
);
create table if not exists public.activity_log (
 id uuid primary key default gen_random_uuid(), actor uuid references auth.users(id) on delete set null,
 action text not null, entity_type text not null, entity_id text, details jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);

create or replace function public.is_active_staff() returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.profiles p where p.id=auth.uid() and p.active=true);
$$;
create or replace function public.is_owner() returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.profiles p where p.id=auth.uid() and p.active=true and p.role='owner');
$$;
create or replace function public.has_permission(permission_name text) returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.profiles p where p.id=auth.uid() and p.active=true and (p.role='owner' or coalesce((p.permissions->>permission_name)::boolean,false)));
$$;

alter table public.profiles enable row level security;
alter table public.bookings enable row level security;
alter table public.tow_requests enable row level security;
alter table public.reviews enable row level security;
alter table public.cars enable row level security;
alter table public.services enable row level security;
alter table public.work_gallery enable row level security;
alter table public.site_settings enable row level security;
alter table public.activity_log enable row level security;

create policy "staff can read own profile" on public.profiles for select to authenticated using (id=auth.uid() or public.is_owner());
create policy "owner manages profiles" on public.profiles for all to authenticated using (public.is_owner()) with check (public.is_owner());
create policy "staff with booking permission read bookings" on public.bookings for select to authenticated using (public.has_permission('bookings'));
create policy "staff with booking permission update bookings" on public.bookings for update to authenticated using (public.has_permission('bookings')) with check (public.has_permission('bookings'));
create policy "staff with booking permission delete bookings" on public.bookings for delete to authenticated using (public.has_permission('bookings'));
create policy "staff with tow permission read tow requests" on public.tow_requests for select to authenticated using (public.has_permission('tows'));
create policy "staff with tow permission update tow requests" on public.tow_requests for update to authenticated using (public.has_permission('tows')) with check (public.has_permission('tows'));
create policy "staff with tow permission delete tow requests" on public.tow_requests for delete to authenticated using (public.has_permission('tows'));
create policy "public can read approved reviews" on public.reviews for select to anon, authenticated using (approved=true or public.has_permission('reviews'));
create policy "review staff manage reviews" on public.reviews for all to authenticated using (public.has_permission('reviews')) with check (public.has_permission('reviews'));
create policy "public can read available cars" on public.cars for select to anon, authenticated using (status='Available' or public.has_permission('cars'));
create policy "car staff manage cars" on public.cars for all to authenticated using (public.has_permission('cars')) with check (public.has_permission('cars'));
create policy "public can read active services" on public.services for select to anon, authenticated using (active=true or public.has_permission('services'));
create policy "service staff manage services" on public.services for all to authenticated using (public.has_permission('services')) with check (public.has_permission('services'));
create policy "public can read published work" on public.work_gallery for select to anon, authenticated using (published=true or public.has_permission('work'));
create policy "work staff manage gallery" on public.work_gallery for all to authenticated using (public.has_permission('work')) with check (public.has_permission('work'));
create policy "public can read site settings" on public.site_settings for select to anon, authenticated using (true);
create policy "settings staff manage site settings" on public.site_settings for all to authenticated using (public.has_permission('settings')) with check (public.has_permission('settings'));
create policy "staff read activity log" on public.activity_log for select to authenticated using (public.is_active_staff());
create policy "staff add activity log" on public.activity_log for insert to authenticated with check (public.is_active_staff());

insert into public.services(name,description,price_text,featured,active) values
('Vehicle Diagnostics','Scan and assess warning lights, drivability concerns and vehicle faults.','Price on assessment',true,true),
('Mechanical Repairs','Maintenance and repair work based on vehicle inspection.','Quote after inspection',true,true),
('Towing & Roadside Assistance','Request roadside recovery and towing assistance in Abuja.','Contact for quote',true,true),
('Vehicle Sales','Enquire about available vehicles and arrange a viewing.','See vehicle listing',false,true)
on conflict do nothing;
insert into public.site_settings(id) values(1) on conflict(id) do nothing;

-- First Owner bootstrap (do this AFTER creating the owner's user in Supabase Auth):
-- insert into public.profiles(id, full_name, role, active, permissions)
-- values ('YOUR_AUTH_USER_UUID', 'AAV Owner', 'owner', true, '{"bookings":true,"tows":true,"reviews":true,"cars":true,"services":true,"work":true,"settings":true,"staff":true}'::jsonb)
-- on conflict(id) do update set role='owner', active=true;
-- Optional sample content for staging only; remove or replace before launch.
insert into public.reviews(name,rating,body,approved) values
('Sample Customer',5,'Sample review for layout testing only. Replace with a real, consented customer review.',false)
on conflict do nothing;
